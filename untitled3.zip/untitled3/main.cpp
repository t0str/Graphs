#include <iostream>
#include <vector>
#include <fstream>
#include "function.h"
using namespace std;

int main() {
    vector<vector<int>> matrInc, listSmej, listRebr, matrSmej;
    int isOrient;
    ofstream fout("output.txt");
    while (true) {
        int number;
        matrSmej = OperationIn(isOrient);
        if(matrSmej.empty()){
            return 0;
        }
        listRebr = MatrSmejToListRebr(matrSmej);
        listSmej = MatrSmejToListSmej(matrSmej);
        matrInc = MatrSmejToMatrInc(matrSmej, isOrient);
        cout << "Wwedite nomer operacii(2):";
        cin >> number;
        bool inFile = true;
        switch (number) {
            case 1:cout << "Reber:" << NumberRebr(matrSmej, isOrient);
                break;
            case 2:NumberDegree(matrSmej);
                break;
            case 3:cout << "V file?";
                cin >> inFile;
                if (inFile)
                    printMatr(matrInc, fout);
                else printMatr(matrInc, cout);
                cout << '\n';
                break;
            case 4:cout << "V file?";
                cin >> inFile;
                if (inFile)
                    printMatr(matrSmej, fout);
                else printMatr(matrSmej, cout);
                cout << '\n';
                break;
            case 5:cout << "V file?";
                cin >> inFile;
                if (inFile) {
                    printMatr(listRebr, fout);
                } else printMatr(listRebr, cout);
                cout << '\n';
                break;
            case 6:cout << "V file?";
                cin >> inFile;
                if (inFile) {
                    printMatr(listSmej, fout);
                } else {
                    printMatr(listSmej, cout);
                }
                cout << '\n';
                break;
            default: return 0;
        }
    }
}