

#ifndef UNTITLED3__FUNCTION_H_
#define UNTITLED3__FUNCTION_H_
#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
ostream &printMatr(vector<vector<int>> &matrix, ostream &out);
vector<vector<int>> MatrSmej(istream &in);
vector<vector<int>> MatrInc(istream &in);
vector<vector<int>> ListRebr(istream &in);
vector<vector<int>> ListSmej(istream &in);
vector<vector<int>> ListRebrToMatrSmej(vector<vector<int>> &listRebr, int n);
vector<vector<int>> MatrIncToMatrSmej(vector<vector<int>> &matrInc);
vector<vector<int>> ListSmejToMatrSmej(vector<vector<int>> &listSmej);
vector<vector<int>> MatrSmejToListSmej(vector<vector<int>> &matrSmej);
vector<vector<int>> MatrSmejToListRebr(vector<vector<int>> &matrSmej);
int NumberRebr(vector<vector<int>> &matrSmej, int isOrient);
vector<vector<int>> MatrSmejToMatrInc(vector<vector<int>> &matrSmej, int isOrient);
void NumberDegree(vector<vector<int>> &matrSmej);
vector<vector<int>> OperationIn(int& isOrient);
#endif //UNTITLED3__FUNCTION_H_
