
#include "function.h"
using namespace std;

// вывод матриц.
ostream &printMatr(vector<vector<int>> &matrix, ostream &out) {
    out << '\n';
    for (auto &i : matrix) {
        for (int j : i) {
            out << j << '\t';
        }
        out << '\n';
    }
    return out;
}

// Ввод матрицы смежности.
vector<vector<int>> MatrSmej(istream &in) {
    int a, n;
    cout<<"Wwedite colichestvo vershin:";
    in >> n;
    vector<vector<int>> matrSmej(n);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            in >> a;
            matrSmej[i].push_back(a);
        }
    }
    return matrSmej;
}

// Ввод матрицы инцедентности.
vector<vector<int>> MatrInc(istream &in) {
    int n, k;
    int a;
    cout<<"Wwedite colichestvo vershin, a potom colichestvo reber:";
    in >> n >> k;
    vector<vector<int>> matrInc(n);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < k; j++) {
            in >> a;
            matrInc[i].push_back(a);
        }
    }
    return matrInc;
}

// Ввод списка рёбер.
vector<vector<int>> ListRebr(istream &in) {
    int n;
    int edge1, edge2;
    cout<<"Wwedite colichestvo reber:";
    in >> n;
    vector<vector<int>> listRebr(n);
    for (int i = 0; i < n; i++) {
        in >> edge1 >> edge2;
        listRebr[i].push_back(edge1);
        listRebr[i].push_back(edge2);
    }
    return listRebr;
}

// Ввод списка смежности.
vector<vector<int>> ListSmej(istream &in) {
    int n;
    cout<<"Wwedite colichestvo vershin:";
    cin >> n;
    vector<vector<int>> listSmej(n);
    for (int i = 0; i < n; i++) {
        int a;
        cout<<"Wwedite colichestvo smezhnih vershin:";
        cin >> a;
        for (int j = 0; j < a; j++) {
            int b;
            cin >> b;
            listSmej[i].push_back(b);
        }
    }
    return listSmej;
}

// Преобразование списка ребёр в матрицу смежности.
vector<vector<int>> ListRebrToMatrSmej(vector<vector<int>> &listRebr, int n) {
    vector<vector<int>> matrSmej(n);
    for (size_t i = 0; i < n; i++)
        for (size_t j = 0; j < n; j++)
            matrSmej[i].push_back(0);
    for (auto &i : listRebr)
        matrSmej[i[0]][i[1]] = 1;
    return matrSmej;
}

// Преобразование матрицы инцедентности в матрицу смежности.
vector<vector<int>> MatrIncToMatrSmej(vector<vector<int>> &matrInc) {
    vector<vector<int>> matrSmej(matrInc.size());
    size_t n = matrInc.size();
    for (size_t i = 0; i < n; i++)
        for (size_t j = 0; j < n; j++)
            matrSmej[i].push_back(0);
    vector<vector<int>> listRebr(matrInc[0].size());
    for (int j = 0; j < matrInc[0].size(); j++) {
        int a = -1, b = -1;
        bool orient = true;
        for (int i = 0; i < matrInc.size(); i++)
            if (matrInc[i][j] != 0) {
                if (a == -1) {
                    a = i;
                } else {
                    b = i;
                }
                if (matrInc[i][j] == -1) {
                    orient = false;
                }
            }
        if (orient) {
            matrSmej[a][b] = 1;
            matrSmej[b][a] = 1;
        } else {
            if (matrInc[a][j] == -1)
                matrSmej[b][a] = 1;
            else matrSmej[a][b] = 1;
        }
    }
    return matrSmej;
}

// Преобразование списка смежности в матрицу смежности.
vector<vector<int>> ListSmejToMatrSmej(vector<vector<int>> &listSmej) {
    vector<vector<int>> matrSmej(listSmej.size());
    for (size_t i = 0; i < listSmej.size(); i++)
        for (size_t j = 0; j < listSmej.size(); j++)
            matrSmej[i].push_back(0);
    for (size_t i = 0; i < listSmej.size(); i++)
        for (size_t j = 0; j < listSmej[i].size(); j++)
            matrSmej[i][listSmej[i][j]] = 1;
    return matrSmej;
}

// Преобразование матрицы смежности в спиок смежности.
vector<vector<int>> MatrSmejToListSmej(vector<vector<int>> &matrSmej) {
    vector<vector<int>> listSmej(matrSmej.size());
    for (size_t i = 0; i < matrSmej.size(); i++)
        for (size_t j = 0; j < matrSmej[i].size(); j++)
            if (matrSmej[i][j] == 1)
                listSmej[i].push_back(static_cast<int>(j));
    return listSmej;
}

// Преобразование матрицы смежности в список рёбер.
vector<vector<int>> MatrSmejToListRebr(vector<vector<int>> &matrSmej) {
    vector<vector<int>> listRebr;
    for (size_t i = 0; i < matrSmej.size(); i++)
        for (size_t j = 0; j < matrSmej[i].size(); j++)
            if (matrSmej[i][j] == 1)
                listRebr.push_back({static_cast<int>(i), static_cast<int>(j)});
    return listRebr;
}

// Количество рёбер.
int NumberRebr(vector<vector<int>> &matrSmej, int isOrient) {
    int sum = 0;
    for (const auto &value : matrSmej)
        for (auto val : value)
            sum += val;
    return isOrient == 0 ? sum / 2 : sum;
}

// Преобразование матрицы смежности в матрицу инцедентности.
vector<vector<int>> MatrSmejToMatrInc(vector<vector<int>> &matrSmej, int isOrient) {
    vector<vector<int>> matrInc(matrSmej.size());
    for (auto &i : matrInc)
        for (int j = 0; j < NumberRebr(matrSmej, isOrient); j++)
            i.push_back(0);
    int rebro = 0;
    for (size_t i = 0; i < matrSmej.size(); i++)
        for (size_t j = 0; j < matrSmej[i].size(); j++) {
            if (matrSmej[i][j] == 1) {
                if (matrSmej[j][i] == 1) {
                    if (i >= j) {
                        matrInc[i][rebro] = 1;
                        matrInc[j][rebro] = 1;
                        rebro++;
                    }
                } else {
                    matrInc[i][rebro] = 1;
                    matrInc[j][rebro] = -1;
                    rebro++;
                }
            }
        }
    return matrInc;
}

// Подсчёт степеней(полустепеней исхода)
void NumberDegree(vector<vector<int>> &matrSmej) {
    for (const auto &value : matrSmej) {
        int degree = 0;
        for (auto val : value) degree++;
        cout << "stepen/polustepen:" << degree << '\n';
    }
}

// Операция 1(ввод графа).
vector<vector<int>> OperationIn(int& isOrient){
    vector<vector<int>> matrInc;
    vector<vector<int>> listSmej;
    vector<vector<int>> listRebr;
    vector<vector<int>> matrSmej;
    int numberVertex;
    ifstream fin("input.txt");
    ofstream fout("output.txt");
        int number;
        bool file;
        cout << "Wwedite nomer operacii:";
        cin >> number;
        switch (number) {
            case 1:cout << "iz faila?";
                cin >> file;
                cout << "Orientirovan?";
                cin >> isOrient;
                if (file)
                    matrInc = MatrInc(fin);
                else matrInc = MatrInc(cin);
                matrSmej = MatrIncToMatrSmej(matrInc);
                break;
            case 2:cout << "iz faila?";
                cin >> file;
                cout << "Orientirovan?";
                cin >> isOrient;
                if (file)
                    matrSmej = MatrSmej(fin);
                else matrSmej = MatrSmej(cin);
                break;
            case 3:cout << "iz faila?";
                cin >> file;
                cout << "Orientirovan?";
                cin >> isOrient;
                if (file)
                    listSmej = ListSmej(fin);
                else listSmej = ListSmej(cin);
                matrSmej = ListSmejToMatrSmej(listSmej);
                break;
            case 4:cout << "iz faila?";
                cin >> file;
                cout << "Orientirovan?";
                cin >> isOrient;
                cout << "Skolko vershin?";
                cin >> numberVertex;
                if (file)
                    listRebr = ListRebr(fin);
                else {
                    listRebr = ListRebr(cin);
                }
                matrSmej = ListRebrToMatrSmej(listRebr, numberVertex);
                break;
            default: break;
        }
        return matrSmej;
}
